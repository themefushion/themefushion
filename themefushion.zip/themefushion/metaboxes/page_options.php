<?php
$options = array();
$default_sidebars = function_exists('gostore_get_list_sidebars')? gostore_get_list_sidebars(): array();
$sidebar_options = array();
foreach( $default_sidebars as $key => $_sidebar ){
	$sidebar_options[$_sidebar['id']] = $_sidebar['name'];
}

/* Get list menus */
$menus = array('0' => esc_html__('Default', 'themefushion'));
$nav_terms = get_terms( array( 'taxonomy' => 'nav_menu', 'hide_empty' => false ) );
if( is_array($nav_terms) ){
	foreach( $nav_terms as $term ){
		$menus[$term->term_id] = $term->name;
	}
}

/* Get list Footer Blocks */
$footer_blocks = function_exists('gostore_get_footer_block_options')? gostore_get_footer_block_options(): array();
$footer_blocks['0'] = esc_html__('Default', 'themefushion');

$options[] = array(
				'id'		=> 'page_layout_heading'
				,'label'	=> esc_html__('Page Layout', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'heading'
			);

$options[] = array(
				'id'		=> 'layout_fullwidth'
				,'label'	=> esc_html__('Layout Fullwidth', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'select'
				,'options'	=> array(
									'default'	=> esc_html__('Default', 'themefushion')
									,'1' 		=> esc_html__('Yes', 'themefushion')
									,'0' 		=> esc_html__('No', 'themefushion')
								)
			);
			
$options[] = array(
				'id'		=> 'header_layout_fullwidth'
				,'label'	=> esc_html__('Header Layout Fullwidth', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'select'
				,'options'	=> array(
									'1' 	=> esc_html__('Yes', 'themefushion')
									,'0' 	=> esc_html__('No', 'themefushion')
								)
			);

$options[] = array(
				'id'		=> 'main_content_layout_fullwidth'
				,'label'	=> esc_html__('Main Content Layout Fullwidth', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'select'
				,'options'	=> array(
									'1' 	=> esc_html__('Yes', 'themefushion')
									,'0' 	=> esc_html__('No', 'themefushion')
								)
			);

$options[] = array(
				'id'		=> 'footer_layout_fullwidth'
				,'label'	=> esc_html__('Footer Layout Fullwidth', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'select'
				,'options'	=> array(
									'1' 	=> esc_html__('Yes', 'themefushion')
									,'0' 	=> esc_html__('No', 'themefushion')
								)
			);

$options[] = array(
				'id'		=> 'layout_style'
				,'label'	=> esc_html__('Layout Style', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'select'
				,'options'	=> array(
									'default'  	=> esc_html__('Default', 'themefushion')
									,'boxed' 	=> esc_html__('Boxed', 'themefushion')
									,'wide' 	=> esc_html__('Wide', 'themefushion')
								)
			);			
			
$options[] = array(
				'id'		=> 'page_layout'
				,'label'	=> esc_html__('Page Layout', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'select'
				,'options'	=> array(
									'0-1-0'  => esc_html__('Fullwidth', 'themefushion')
									,'1-1-0' => esc_html__('Left Sidebar', 'themefushion')
									,'0-1-1' => esc_html__('Right Sidebar', 'themefushion')
									,'1-1-1' => esc_html__('Left & Right Sidebar', 'themefushion')
								)
			);
			
$options[] = array(
				'id'		=> 'left_sidebar'
				,'label'	=> esc_html__('Left Sidebar', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'select'
				,'options'	=> $sidebar_options
			);

$options[] = array(
				'id'		=> 'right_sidebar'
				,'label'	=> esc_html__('Right Sidebar', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'select'
				,'options'	=> $sidebar_options
			);
			
$options[] = array(
				'id'		=> 'header_breadcrumb_heading'
				,'label'	=> esc_html__('Header - Breadcrumb', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'heading'
			);
			
$options[] = array(
				'id'		=> 'header_layout'
				,'label'	=> esc_html__('Header Layout', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'select'
				,'options'	=> array(
									'default'  	=> esc_html__('Default', 'themefushion')
									,'v1'  		=> esc_html__('Header Layout 1', 'themefushion')
									,'v2' 		=> esc_html__('Header Layout 2', 'themefushion')
									,'v3' 		=> esc_html__('Header Layout 3', 'themefushion')
									,'v4' 		=> esc_html__('Header Layout 4', 'themefushion')
								)
			);			
			
$options[] = array(
				'id'		=> 'menu_id'
				,'label'	=> esc_html__('Primary Menu', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'select'
				,'options'	=> $menus
			);
			
$options[] = array(
				'id'		=> 'vertical_menu_id'
				,'label'	=> esc_html__('Vertical Menu', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'select'
				,'options'	=> $menus
			);			
			
$options[] = array(
				'id'		=> 'display_vertical_menu_by_default'
				,'label'	=> esc_html__('Display Vertical Menu By Default', 'themefushion')
				,'desc'		=> esc_html__('If this option is enabled, you wont need to hover to see the vertical menu', 'themefushion')
				,'type'		=> 'select'
				,'default'	=> 0
				,'options'	=> array(
								'1'		=> esc_html__('Yes', 'themefushion')
								,'0'	=> esc_html__('No', 'themefushion')
								)
			);
			
$options[] = array(
				'id'		=> 'show_page_title'
				,'label'	=> esc_html__('Show Page Title', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'select'
				,'options'	=> array(
								'1'		=> esc_html__('Yes', 'themefushion')
								,'0'	=> esc_html__('No', 'themefushion')
								)
			);
			
$options[] = array(
				'id'		=> 'show_breadcrumb'
				,'label'	=> esc_html__('Show Breadcrumb', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'select'
				,'options'	=> array(
								'1'		=> esc_html__('Yes', 'themefushion')
								,'0'	=> esc_html__('No', 'themefushion')
								)
			);
			
$options[] = array(
				'id'		=> 'breadcrumb_layout'
				,'label'	=> esc_html__('Breadcrumb Layout', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'select'
				,'options'	=> array(
									'default'  	=> esc_html__('Default', 'themefushion')
									,'v1'  		=> esc_html__('Breadcrumb Layout 1', 'themefushion')
									,'v2' 		=> esc_html__('Breadcrumb Layout 2', 'themefushion')
									,'v3' 		=> esc_html__('Breadcrumb Layout 3', 'themefushion')
								)
			);
			
$options[] = array(
				'id'		=> 'breadcrumb_bg_parallax'
				,'label'	=> esc_html__('Breadcrumb Background Parallax', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'select'
				,'options'	=> array(
								'default'  	=> esc_html__('Default', 'themefushion')
								,'1'		=> esc_html__('Yes', 'themefushion')
								,'0'		=> esc_html__('No', 'themefushion')
								)
			);
			
$options[] = array(
				'id'		=> 'bg_breadcrumbs'
				,'label'	=> esc_html__('Breadcrumb Background Image', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'upload'
			);	
			
$options[] = array(
				'id'		=> 'logo'
				,'label'	=> esc_html__('Logo', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'upload'
			);
			
$options[] = array(
				'id'		=> 'logo_mobile'
				,'label'	=> esc_html__('Mobile Logo', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'upload'
			);		
			
$options[] = array(
				'id'		=> 'logo_sticky'
				,'label'	=> esc_html__('Sticky Logo', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'upload'
			);

$options[] = array(
				'id'		=> 'page_slider_heading'
				,'label'	=> esc_html__('Page Slider', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'heading'
			);			
			
$revolution_exists = class_exists('RevSliderSlider');

$page_sliders = array();
$page_sliders[0] = esc_html__('No Slider', 'themefushion');
if( $revolution_exists ){
	$page_sliders['revslider']	= esc_html__('Revolution Slider', 'themefushion');
}

$options[] = array(
				'id'		=> 'page_slider'
				,'label'	=> esc_html__('Page Slider', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'select'
				,'options'	=> $page_sliders
			);
			
$options[] = array(
				'id'		=> 'page_slider_position'
				,'label'	=> esc_html__('Page Slider Position', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'select'
				,'options'	=> array(
							'before_header'			=> esc_html__('Before Header', 'themefushion')
							,'before_main_content'	=> esc_html__('Before Main Content', 'themefushion')
							)
				,'default'	=> 'before_main_content'
			);

if( $revolution_exists ){
	global $wpdb;
	$revsliders = array();
	$revsliders[0] = esc_html__('Select a slider', 'themefushion');
	
	$sliders = $wpdb->get_results("SELECT * FROM ".$wpdb->prefix."revslider_sliders where type != 'folder'");
	if( $sliders ){
		foreach( $sliders as $slider ){
			$revsliders[$slider->alias] = $slider->title;
		}
	}
				
	$options[] = array(
					'id'		=> 'rev_slider'
					,'label'	=> esc_html__('Select Revolution Slider', 'themefushion')
					,'desc'		=> ''
					,'type'		=> 'select'
					,'options'	=> $revsliders
				);
}

$options[] = array(
				'id'		=> 'page_footer_heading'
				,'label'	=> esc_html__('Page Footer', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'heading'
			);
	
$options[] = array(
				'id'		=> 'footer_block'
				,'label'	=> esc_html__('Footer Block', 'themefushion')
				,'desc'		=> ''
				,'type'		=> 'select'
				,'options'	=> $footer_blocks
			);
?>