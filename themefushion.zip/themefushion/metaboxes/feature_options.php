<?php 
$options = array();

$options[] = array(
				'id'		=> 'url'
				,'label'	=> esc_html__('URL', 'themefushion')
				,'desc'		=> esc_html__('Enter an URL that applies to this feature. For example: https://themeforest.net/user/themefushion/', 'themefushion')
				,'type'		=> 'text'
			);
?>